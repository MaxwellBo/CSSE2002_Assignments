package railway.gui;

/**
 * The model for the Railway Manager.
 */
public class RailwayModel {

    // REMOVE THIS LINE AND DECLARE ANY VARIABLES YOU REQUIRE HERE

    /**
     * Initialises the model for the Railway Manager.
     */
    public RailwayModel() {
        // REMOVE THIS LINE AND WRITE THIS METHOD
    }

    // REMOVE THIS LINE AND ADD YOUR OWN METHODS ETC HERE

}
