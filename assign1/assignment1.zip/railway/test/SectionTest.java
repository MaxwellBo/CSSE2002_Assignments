package railway.test;

import railway.*;
import org.junit.Assert;
import org.junit.Test;

/**
 * Basic tests for the {@link Section} implementation class.
 * 
 * Write your own junit4 tests for the class here.
 */
public class SectionTest {

    @Test
    public void test() {
        Assert.fail();
    }
}
